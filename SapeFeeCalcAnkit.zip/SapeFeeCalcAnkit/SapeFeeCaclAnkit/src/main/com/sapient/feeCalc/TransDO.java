package main.com.sapient.feeCalc;

import java.util.Date;

public class TransDO {

	private String ExtTransId;
	private String ClientId;
	private String SecurityId;
	private String transType;
	private Date transDate;
	private Double marketVal;
	private Boolean priorityFlag;
	private Double transFees;
	
	public String getExtTransId() {
		return ExtTransId;
	}
	public void setExtTransId(String extTransId) {
		ExtTransId = extTransId;
	}
	public String getClientId() {
		return ClientId;
	}
	public void setClientId(String clientId) {
		ClientId = clientId;
	}
	public String getSecurityId() {
		return SecurityId;
	}
	public void setSecurityId(String securityId) {
		SecurityId = securityId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public Double getMarketVal() {
		return marketVal;
	}
	public void setMarketVal(Double marketVal) {
		this.marketVal = marketVal;
	}
	public Boolean getPriorityFlag() {
		return priorityFlag;
	}
	public void setPriorityFlag(String priorityFlag) {
		
		if(priorityFlag != null && priorityFlag.equalsIgnoreCase(TransConstants.PRIORITY_FLAG_N)) {
			this.priorityFlag = false;
		}else if (priorityFlag != null && priorityFlag.equalsIgnoreCase(TransConstants.PRIORITY_FLAG_Y)) {
			this.priorityFlag = true;
		}
		
	}
	public Double getTransFees() {
		return transFees;
	}
	public void setTransFees(Double transFees) {
		this.transFees = transFees;
	}
}
