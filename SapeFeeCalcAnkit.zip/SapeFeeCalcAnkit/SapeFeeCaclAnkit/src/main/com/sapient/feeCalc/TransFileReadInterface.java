package main.com.sapient.feeCalc;

import java.util.List;

public interface TransFileReadInterface {

	public List<TransDO> readCSVFile(String fileLoc);
	public List<TransDO> readTXTFile(String fileLoc);
	public List<TransDO> readXMLFile(String fileLoc);
}
