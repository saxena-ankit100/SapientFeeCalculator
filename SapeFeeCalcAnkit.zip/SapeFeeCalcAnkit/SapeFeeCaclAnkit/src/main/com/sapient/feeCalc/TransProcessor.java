package main.com.sapient.feeCalc;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class TransProcessor {

	
	Double transFees;
	
	public List<TransDO> calculateTransFee(List<TransDO> transDetail){
		
		List<TransDO> transWithFees = new ArrayList<>();
		
		for (TransDO transDO : transDetail) {
			
			if(intraDayTrans(transDO,transDetail)) {
				transDO.setTransFees(TransConstants.INTRADAY_FEES);
			}else if(normalHighPriority(transDO)) {
				transDO.setTransFees(TransConstants.NORMAL_HIGH_PRIORITY);
			}else if(normalSellWithdraw(transDO)) {
				transDO.setTransFees(TransConstants.NORMAL_SELL_WITHDRAW);
			}else if(normalBuyDeposit(transDO)) {
				transDO.setTransFees(TransConstants.NORMAL_BUY_DEPOSIT);
			}
			transWithFees.add(transDO);
		}
		
		return transWithFees;
	}

	private boolean normalBuyDeposit(TransDO transDO) {
		
		if(transDO != null && !transDO.getPriorityFlag() 
				&& (transDO.getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_BUY) ||
						transDO.getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_DEPOSIT))){
			return true;
		}
		return false;
	}

	private boolean normalSellWithdraw(TransDO transDO) {

		if(transDO != null && !transDO.getPriorityFlag() 
				&& (transDO.getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_SELL) ||
						transDO.getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_WITHDRAW))) {
			return true;
		}
		return false;
	}

	private boolean normalHighPriority(TransDO transDO) {

		if(transDO != null && transDO.getPriorityFlag()) {
			return true;
		}
		return false;
	}

	private boolean intraDayTrans(TransDO transDO, List<TransDO> transDetail) {

		boolean intraDayTrans = false;
		
		List<TransDO> filterTrans = transDetail.stream().filter(td -> td.getClientId().equalsIgnoreCase(transDO.getClientId())).
				filter(td -> td.getSecurityId().equalsIgnoreCase(transDO.getSecurityId())).
				filter(td -> td.getTransDate().compareTo(transDO.getTransDate()) == 0).collect(Collectors.toList());
		
		if(filterTrans!=null && filterTrans.size() == 2) {
			if (filterTrans.get(0).getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_BUY)
					&& filterTrans.get(1).getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_SELL)) {
				intraDayTrans = true;
			}else if (filterTrans.get(0).getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_SELL)
					&& filterTrans.get(1).getTransType().equalsIgnoreCase(TransConstants.TRANSACTION_TYPE_BUY)){
				intraDayTrans = true;
			}
		}
		return intraDayTrans;
	}
	
	public void transPrinter (List<TransDO> transDetail) {
		
		if(transDetail != null && transDetail.size()>0) {
		System.out.println("Calculated Fees:-");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Client Id | Transaction Type | Transaction Date | Priority       | Processing Fee |");
		for (TransDO trans : transDetail) {
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			String date = sdf.format(trans.getTransDate());
			System.out.println("--------------------------------------------------------------------------------");
			System.out.println(trans.getClientId() + "\t  | " + trans.getTransType() + " \t     | " +
			date + "\t| " + (trans.getPriorityFlag() ? "HIGH \t" : "NORMAL") + " \t | "+
			trans.getTransFees() + "\t|");
		}
	}
	}
}
