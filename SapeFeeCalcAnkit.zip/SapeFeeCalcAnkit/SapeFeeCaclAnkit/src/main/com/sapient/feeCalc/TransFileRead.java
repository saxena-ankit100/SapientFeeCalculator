package main.com.sapient.feeCalc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class TransFileRead implements TransFileReadInterface{

	@Override
	public List<TransDO> readCSVFile(String fileLoc) {

		List<TransDO> transactionList = new ArrayList<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileLoc));
			String line;
			while((line = br.readLine()) != null) {
				String[] st= line.split(TransConstants.COMMA_DELIMITER);
				TransDO transObj = new TransDO();
				transObj = makeTransObject(st);
				transactionList.add(transObj);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return transactionList;
	}

	private TransDO makeTransObject(String[] trans) {
		
		TransDO transaction = new TransDO();
		
		transaction.setExtTransId(trans[0]);
		transaction.setClientId(trans[1]);
		transaction.setSecurityId(trans[2]);
		transaction.setTransType(trans[3]);
		try {
			transaction.setTransDate(new SimpleDateFormat("dd/MM/yyyy").parse(trans[4]));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		transaction.setMarketVal(Double.parseDouble(trans[5]));
		transaction.setPriorityFlag(trans[6]);
		
		return transaction;	
	}
	
	public List<TransDO> read (String FileType, String fileLoc){
		
		List<TransDO> transList = new ArrayList<>();
		if(FileType.equalsIgnoreCase(TransConstants.TXT_FILE)) {
			transList = readTXTFile(fileLoc);
		}else if(FileType.equalsIgnoreCase(TransConstants.CSV_FILE)) {
			transList = readCSVFile(fileLoc);
		}else if(FileType.equalsIgnoreCase(TransConstants.XML_FILE)) {
			transList = readXMLFile(fileLoc);
		}
		
		return transList;
		
	}

	@Override
	public List<TransDO> readTXTFile(String fileLoc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TransDO> readXMLFile(String fileLoc) {
		// TODO Auto-generated method stub
		return null;
	}

}
