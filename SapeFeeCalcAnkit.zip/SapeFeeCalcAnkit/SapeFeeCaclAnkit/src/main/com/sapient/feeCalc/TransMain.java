package main.com.sapient.feeCalc;

import java.util.ArrayList;
import java.util.List;

public class TransMain {

	public static void main(String[] args) {

		TransFileRead trf = new TransFileRead();
		String fileLoc = "Sample_data.csv";
		List<TransDO> transactioList = new ArrayList<>();
		TransProcessor trPro = new TransProcessor();
		transactioList = trPro.calculateTransFee(trf.read(TransConstants.CSV_FILE, fileLoc));
		
		trPro.transPrinter(transactioList);
	}

}
