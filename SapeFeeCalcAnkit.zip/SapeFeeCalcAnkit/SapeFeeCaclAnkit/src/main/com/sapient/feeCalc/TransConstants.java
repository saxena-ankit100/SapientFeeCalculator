package main.com.sapient.feeCalc;

public class TransConstants {

	public static String COMMA_DELIMITER = ",";
	public static String TXT_FILE = "TXT";
	public static String CSV_FILE = "CSV";
	public static String XML_FILE = "XML";
	public static Double INTRADAY_FEES = 10d;
	public static Double NORMAL_HIGH_PRIORITY = 500d;
	public static Double NORMAL_SELL_WITHDRAW = 100d;
	public static Double NORMAL_BUY_DEPOSIT = 50d;
	public static String TRANSACTION_TYPE_BUY = "BUY";
	public static String TRANSACTION_TYPE_SELL = "SELL";
	public static String TRANSACTION_TYPE_DEPOSIT = "DEPOSIT";
	public static String TRANSACTION_TYPE_WITHDRAW = "WITHDRAW";
	public static String PRIORITY_FLAG_N = "N";
	public static String PRIORITY_FLAG_Y = "Y";
}
